% Mathmatical Modelling for SUSTank


%% vehicle kinetic 1

% METHOD 1
% mean angular velocity = max rotational angel/T 
% where T_LF,T_RF,T_LB,T_RB are automaticlly given, controlled by pressure or
% current? one idea is to controlled the pressure/current to adjust T
% we need to find pressure/current vs. T?

%   Find T_LF/T_RF/T_LB/T_RB vs. v/w/rc


% pahse analysis in one cycle
% define variables
syms S a b h_0 h_min T_LF T_RF T_LB T_RB R_LF R_RF R_LB R_RB R A B C  phase real
assume(a>0) %short cease length
assume(b>0) %long cease length
assume(h_0>0) %original height
assume(h_min>0) %min height
assume(T_LF>=0) %time of one circle on the left front actuator
assume(T_RF>=0) %time of one circle on the right front actuator
assume(T_LB>=0) %time of one cycle on the left back actuator
assume(T_RB>=0) %time of one cycle on the right back actuator
assume(R>0) %thickness of wheel and clawer
assume(phase>0) %phase difference of front and back wheels
assume(S>0)%B = S = distance of two sides
assume(R_LF>0)
assume(R_RF>0)
assume(R_LB>0) 
assume(R_RB>0) 

% substitude real geometry variable, measured in Solidworks
h_min = 0.018; % taken from experience
a = 0.01848;
b = 0.04038;
h_0 = 0.0359;
A=0;
B=0;
C=0;
S = 0.30;
R = 0.028;

T_total = 0:0.01:10;
T_change = 0.5:0.01:2;

duty = 0.75;

vy = [];
w = [];
r = [];
k = 1;

% calculate max theta from geometry
% theta is noted as increment,where the initial theta is 60.0231,
% theta_max is total rotational angel - initial theta = 95.8863
% assume each wheel's actuator are the same 
theta_max = 2*asin(sqrt(b^2-h_min^2)/(2*a)) - 2*asin(sqrt(b^2-h_0^2)/(2*a)); % indicate b>h
theta_max_d = theta_max*180/pi;
%each wheel's angular speed in one cycle
for j = T_change
T_LF = j;
T_LB = j;
T_RF = 0.5;
T_RB = 0.5;
R_LF = T_LF;
R_LB = T_LB;
R_RF = T_RF;
R_RB = T_RB;    
    
w_mean_lf = theta_max/T_LF;
w_mean_lb = theta_max/T_LB;
w_mean_rf = theta_max/T_RF;
w_mean_rb = theta_max/T_RB;

lf = w_mean_lf;
lb = w_mean_lb;
rf = w_mean_rf;
rb = w_mean_rb;
phase_L = (1-duty)*(T_LB+R_LB); % 1-duty<coefficeint<duty -----> same v/w/rc for one set of T
phase_R = (1-duty)*(T_RB+R_RB);


wlf = lf*square(2*pi/(T_LF+R_LF)*T_total,duty*100);
for i = 1:length(wlf)
    if wlf(i)<=0
        wlf(i) = 0;
    end
end

wlb = lb*square(2*pi/(T_LB+R_LB)*(T_total+phase_L),duty*100);
for i = 1:length(wlb)
    if wlb(i)<=0
        wlb(i) = 0;
    end
end

wl = max(wlf,wlb);



wrf = rf*square(2*pi/(T_RF+R_RF)*T_total,duty*100);
for i = 1:length(wrf)
    if wrf(i)<=0
        wrf(i) = 0;
    end
end


wrb = rb*square(2*pi/(T_RB+R_RB)*(T_total+phase_R),duty*100);
for i = 1:length(wrb)
    if wrb(i)<=0
        wrb(i) = 0;
    end
end

wr = max(wrf,wrb);


v_r_mean = wr*R;
v_l_mean = wl*R;
vx_mean = 0;
vy_mean = (v_r_mean+v_l_mean)/2;
w_mean = (v_l_mean-v_r_mean)/S;
rc = vy_mean./w_mean;

vy(k) = vy_mean(k);
w(k) = w_mean(k);
r(k) = rc(k);
k = k+1;
end

figure(1)
plot(T_total,wlf,'--rs')
hold on
plot(T_total,wlb)
title("L")
figure(2)
plot(T_total,wl)
title("wl")
figure(3)
plot(T_total,wrf,'--rs')
hold on
plot(T_total,wrb)
title("R")
figure(4)
plot(T_total,wr)
title("wr")


% plot local velocity and COR vs. cycle Time
figure(5)
subplot(1,3,1);
plot(T_total,vy_mean);
title('vy mean');
xlabel("T_TOTAL")
ylabel("vy mean")
subplot(1,3,2);
plot(T_total,w_mean);
title('w mean');
xlabel("T_TOTAL")
ylabel("w mean")
subplot(1,3,3);
plot(T_total,rc);
title('rc');
xlabel("T_TOTAL")
ylabel("rc")
figure(6)
subplot(1,3,1);
plot(T_change,vy);
title('vy');
xlabel("T")
ylabel("vy")
subplot(1,3,2);
plot(T_change,w);
title('w');
xlabel("T")
ylabel("w")
subplot(1,3,3);
plot(T_change,r);
title('r');
xlabel("T")
ylabel("r")


%%

%% vehicle kinetic 2
% METHOD 2: 
% FEA method to get volume of actuator, 
% then dV/dt = dF(phi(t))/dt => w, where current is dV/dt and can be manually
% controlled
% assume phi(t) is time variance


% define variables
syms h_0 h_min a b current
syms phi(t)
assume (phi(t)>=0)
assume(a>0)
assume(b>0)
assume(h_0>0)


% substitude real geometry variable
a = 0.01848;
b = 0.04038;
h_0 = 0.0359;
current1 = -0.005/60;
current2 = -0.002/60;
h_min = 0.018;


Tt1 = 0:0.01:1;
[t,phi1]=ode45(@(t,phi) fun(t,phi,h_0,h_min, a, b, current1),Tt1,0);
figure(1)
scatter(t,phi1);
title('phi1 vs. t');
xlabel("t");
ylabel("phi1");
hold on


[t,phi2]=ode45(@(t,phi) fun(t,phi,h_0,h_min, a, b, current2),Tt1,0);
scatter(t,phi2);
title('phi2 vs. t');
xlabel("t");
ylabel("phi2");


%%
%calculate w using derivation:
w1 = zeros(1,length(t));
w2 = zeros(1,length(t));
for i = 2:length(t)
    de_t = t(i)-t(i-1);
    de_phi = phi1(i,1)-phi1((i-1),1);
    de_phi2 = phi2(i,1)-phi2((i-1),1);
    w1(i) = de_phi/(de_t);
    w2(i) = de_phi2/(de_t);
end

figure(2)
plot(t,w1);
hold on
title('w1 vs. t');
xlabel("t");
ylabel("w1");

wa = [];
wb = [];
for i = 1:length(w1)
    if w1(i) >= 0
        wa(i) = w1(i);
    else
        break;
    end
    
end
plot(t(1:length(wa)),wa);
hold on
for i = 1:length(w2)
    if w2(i) >= 0
        wb(i) = w2(i);
    else
        break;
    end
    
end
plot(t,w2);
hold on
plot(t(1:length(wb)),wb);
hold on


%%
%calculate car speed and analysis phasess in 3 cycles
duty2 = 0.8;

T_LF = length(wb);
T_RF = length(wa);
T_LB = length(wb);
T_RB = length(wa);
R_LF = round(duty2*T_LF);
R_RF = round(duty2*T_RF);
R_LB = round(duty2*T_LB);
R_RB = round(duty2*T_RB);
phase1 = round(0.91*T_LB);
phase2 = round(0.91*T_RB);

delta_lf=[1,zeros(1,T_LF+R_LF),1,zeros(1,T_LF+R_LF),1];
wlf = conv2(wb,delta_lf);
figure(1)
stem(wlf,'--rs')
hold on
delta_lb=[zeros(1,phase1),1,zeros(1,T_LB+R_LB),1,zeros(1,T_LB+R_LB),1];
wlb = conv2(wb,delta_lb);
stem(wlb)
title('wlf & wlb');
W_l = [];
for i = 1:(length(delta_lb)+length(wb)-1)
    if i > (length(delta_lf)+length(wb)-1)
         W_l(i) = wlb(i);
    else
        W_l(i) = max(wlb(i),wlf(i));
    end
end
figure(2)
stem(W_l)
title('W_l');

%w0 = zeros(1,length(w));

delta_rf=[1,zeros(1,T_RF+R_RF),1,zeros(1,T_RF+R_RF),1];
wrf = conv2(wa,delta_rf);
figure(3)
stem(wrf,'--rs')
hold on
delta_rb=[zeros(1,phase2),1,zeros(1,T_RB+R_RB),1,zeros(1,T_RB+R_RB),1];
wrb = conv2(wa,delta_rb);
stem(wrb)
title('wrf & wrb');
W_r = [];
for i = 1:(length(delta_rb)+length(wa)-1)
    if i > (length(delta_rf)+length(wa)-1)
         W_r(i) = wrb(i);
    else
        W_r(i) = max(wrb(i),wrf(i));
    end
end
figure(4)
stem(W_r)
title('W_r');

 if(length(W_r)>length(W_l))
     W_r(length(W_l)+1:length(W_r)) = [];
 else
     W_l(length(W_r)+1:length(W_l)) = [];
 end

v_r_mean = W_r*R;
v_l_mean = W_l*R;
vx_mean = 0;

vy_mean = (v_r_mean+v_l_mean)/2;
w_mean = (v_l_mean-v_r_mean)/S;
rc = vy_mean./w_mean;


% plot local velocity and COR vs. cycle Time
figure(5)
subplot(1,3,1);
stem(vy_mean);
title('vy mean');
xlabel("T_TOTAL")
ylabel("vy mean")
subplot(1,3,2);
stem(w_mean);
title('w mean');
xlabel("T_TOTAL")
ylabel("w mean")
subplot(1,3,3);
stem(rc);
title('rc');
xlabel("T_TOTAL")
ylabel("rc")




 
%%
% get phi v.s. volume
syms h_0 a b h_min current phi real
u1 = h_0 - sqrt((b)^2-(2*a*sin(phi/2+asin(sqrt(b^2-h_0^2)/(2*a))))^2);
V1 = a^2*(h_0-u1)*(sqrt(3)/2 + abs(-sqrt(3)/4-cos(pi/6+phi)/2) + abs(-sqrt(3)/4-sin(pi/3-phi)/2));
a = 0.01848;
b = 0.04038;
h_0 = 0.0359;
h_min = 0.018;
phi_0 = 0;
phi_max = 2*asin(sqrt(b^2-h_min^2)/(2*a)) - 2*asin(sqrt(b^2-h_0^2)/(2*a));
phi = phi_0:0.001:phi_max;

scatter(phi,eval(V1))
title("phi vs. V")
xlabel("phi")
ylabel("V")



















%% dynamic
syms n Ka Kb delA0 delB0 phi h_0 R a b P

%Ka,Kb:coeffision of bending spring
%delA0,delB0:initial angle
%P :pressure

u = h_0 - sqrt((b)^2-(2*a*sin(phi/2+asin(sqrt(b^2-h_0^2)/(2*a))))^2);
delA = (delA0 - acos(1-(2*(h_0-u)^2*(1-sin(phi)))/(2*(h_0-u)^2+ R^2*(1+sin(phi)-cos(phi))^2)))^2;
delB = (delB0 - atan(sqrt(2)*(h_0-u)/(R*(1+sin(phi)-cos(phi)))))^2;
U = 0.5*n*Ka*delA + n*Kb*delB;
Te = diff(U,phi);
V = a^2*(h_0-u)*(sqrt(3)/2 + abs(-sqrt(3)/4-cos(pi/6+phi)/2) + abs(-sqrt(3)/4-sin(pi/3-phi)/2));

%P vs. phi, quasi-static
P1=diff(U,phi)/diff(V,phi);


%P vs. Tout, unquasi-static
Tout = P*diff(V,phi)-Te;


% substitude real variables and plot
R = 0.01862;
a = 0.01848;
b = 0.04038;
h_0 = 0.0359;
Ka = 0.001;
Kb = 0.001;
delA0 = 0.9273;
delB0 = 2.0345;
n = 6;
phi = 0*pi/100:2*pi/100:50*pi/100;
figure(1)
plot(phi,eval(P1));
title("P vs. phi")
xlabel("phi")
ylabel("P")
hold on


P = -10000:-5000:-130000;
phi = 1*pi/100:2*pi/100:50*pi/100;
[xx,yy]=meshgrid(P,phi);
P = xx;
phi = yy;
q1=eval(Tout);
figure(2)
mesh(xx,yy,q1);
title("Tout vs. phi and P")
xlabel("P")
ylabel("phi")
zlabel("Tout")

%%

%P vs. Tout, unquasi-static
Tout = P*diff(V,phi)-Te;


P = -10000:-5000:-130000;
phi = 1*pi/100:2*pi/100:50*pi/100;
[xx,yy]=meshgrid(P,phi);
P = xx;
phi = yy;
q1=eval(Tout);
figure(2)
mesh(xx,yy,q1);
title("Tout vs. phi and P")
xlabel("P")
ylabel("phi")
zlabel("Tout")

%% vehicle dynamic
syms m I g L ux f A B C S R1 r
Fr = 2*Tout/r;
Fl = 2*Tout/r;
ay = (Fr + Fl - f - m*g*sin(A))/m;
ax = 0;
dw = (Fr*(S+R1/2)-Fl*R1-f*(S/2+R1)-(ux*m*g*L)*(cos(A)+cos(C))/4-(S/2+B)*m*g*sin(A))/I;
alocal = [ax; ay; dw];
%aGlobal = H*alocal;



% substitude real variables
C = 0;
A = 0;
B = 0;
f = 2;
R1 = 0;
S = 0.3;
m = 2;
I = 0.1;
g = 10;
ux = 0.3;
L = 0.025;
r = 0.05;

phi = 2*pi/100:2*pi/100:50*pi/100;
P = -10000:-5000:-130000;
[xx,yy]=meshgrid(P,phi);
P = xx;
phi = yy;
q1=eval(dw);
figure(2)
mesh(xx,yy,q1);











