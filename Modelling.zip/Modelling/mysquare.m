function s = mysquare(T,long,val)
s = square(2*pi/T*long,0.001);
for i = 1:length(long)
    if s(i) <= val
        s(i) = 0;
    end
end
end