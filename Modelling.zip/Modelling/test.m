function dphi = test(t,phi,new)
dphi = 2*phi+new;
