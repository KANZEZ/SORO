
function dphi = fun(t,phi,h_0, h_min,a, b, current)
q = (b)^2-(2*a*sin(phi/2+asin(sqrt(b^2-h_0^2)/(2*a))))^2;
u1 = h_0 - sqrt(q);
sqrt(q)
if u1<h_0-h_min && u1>=0
    x1 = asin(sqrt(b^2-h_0^2)/(2*a)) + phi/2;
    x4 = pi/3-phi;
    x5 = pi/6+phi;
    x2 = sin(x4)/2+sqrt(3)/4;
    x3 = cos(x5)/2+sqrt(3)/4;

    dV = -a^2*sqrt(b^2-4*a^2*sin(x1)^2)*((cos(x4)*sign(x2))/2+(sign(x3)*sin(x5))/2) - a^4*cos(x1)*sin(x1)*(abs(x3)+abs(x2)+sqrt(3)/2)*2/(sqrt(b^2-4*a^2*sin(x1)^2));

    dphi = current/dV;

else
    dphi = 0;
    
end


